import React from 'react';

export default function TaskHookForm() {
  return (
    <div>
      Formunuzu react-hook-form kullanarak burada oluşturun. TaskForm
      dosyasındaki HTML yapısını vs app.css içerisindeki classları
      kullanabilirsiniz.
    </div>
  );
}
