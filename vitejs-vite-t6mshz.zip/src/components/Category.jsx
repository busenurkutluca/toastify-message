export default function Category(props) {
  const { category } = props;
  return <div className="category-item">{category}</div>;
}
